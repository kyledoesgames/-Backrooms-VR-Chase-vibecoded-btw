BACKROOMS: HAND-PUSH MULTIPLAYER WebXR prototype

1. Extract this ZIP.
2. Upload index.html to HTTPS static hosting (GitHub Pages works).
3. Both players open the same published page.
4. Host enters a room code and presses CREATE / HOST.
5. Friend enters the same code and presses JOIN ROOM.
6. Press ENTER VR in Quest Browser. Move controller hands into nearby walls/floor to push off.

This is an early Gorilla Tag-inspired approximation: tracked controller movement near surfaces creates an opposite impulse. It is not a full Gorilla Tag physics recreation.
Multiplayer uses PeerJS public signalling and may fail on restricted networks. Both players need internet. This is not a native APK. No hand tracking; controller tracking is required for VR push movement. Desktop controls: WASD, mouse look, Shift sprint, Space jump, M toggles menu.
